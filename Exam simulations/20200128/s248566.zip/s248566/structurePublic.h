#ifndef STRUCTUREPUBLIC_H_INCLUDED
#define STRUCTUREPUBLIC_H_INCLUDED
#include "structurePrivate.h"
wrapperT *loadFile(char *);
wrapperT *createWrapper(int,int);
void reset(wrapperT *);
int findSolutionWrapper(wrapperT *,int *,int);
int findSolution(wrapperT *,int *);
void printSolution(int *,int);
void freeAll(wrapperT *);
#endif // STRUCTUREPUBLIC_H_INCLUDED
