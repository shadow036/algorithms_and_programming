#ifndef STRUCTUREPRIVATE_H_INCLUDED
#define STRUCTUREPRIVATE_H_INCLUDED
typedef struct wrapperS wrapperT;
typedef struct clauseS clauseT;
struct wrapperS{
    int clauseNumber;
    clauseT *clauses;
    int variableNumber;
};
struct clauseS{
    int result;
    int *variables;
    int *bits;
};
#endif // STRUCTUREPRIVATE_H_INCLUDED
