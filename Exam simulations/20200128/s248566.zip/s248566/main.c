#include <stdio.h>
#include <stdlib.h>
#include "structurePublic.h"
int main(int argc,char **argv)
{
    if(argc != 2)
        return EXIT_FAILURE;
    wrapperT *w = loadFile(argv[1]);
    int *solution = (int *) calloc(w->variableNumber,sizeof(int));
    if(solution == NULL){
        fprintf(stdout,"Allocation error!");
        exit(EXIT_FAILURE);
    }
    if(findSolutionWrapper(w,solution,0) == 0)
        fprintf(stdout,"\nThe formula is UNSAT");
    freeAll(w);
    free(w);
    free(solution);
    return 0;
}
