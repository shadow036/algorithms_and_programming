#include "structurePublic.h"
#include <stdio.h>
#include <stdlib.h>
#include <math.h>
wrapperT *loadFile(char *filename){
    FILE *f = fopen(filename,"r");
    if(f == NULL){
        fprintf(stdout,"Error: cannot open the file \"%s\"",filename);
        exit(EXIT_FAILURE);
    }
    int clauseNumber,variableNumber,v;
    fscanf(f,"%d %d",&clauseNumber,&variableNumber);
    wrapperT *w = createWrapper(clauseNumber,variableNumber);
    for(int i=0;i<clauseNumber;i++){
        fscanf(f,"%d",&variableNumber); //"recycled" variable
        for(int j=0;j<variableNumber;j++){
            fscanf(f,"%d",&v);
            w->clauses[i].variables[abs(v)-1] = v/abs(v);   //setting the vth-1 flag to 1 or -1
            /*
            CONTENT OF w->clauses[i].variables[i]
                1: variable X(i+1) is present in the clause
                0: variable X(i+1) is not present in the clause
                -1: variable X(i+1) negated is present in the clause
            */
        }
    }
    return w;
}
wrapperT *createWrapper(int clauseNumber,int variableNumber){
    wrapperT *w = (wrapperT *) malloc(sizeof(wrapperT));
    if(w == NULL){
        fprintf(stdout,"Allocation error!");
        exit(EXIT_FAILURE);
    }
    w->clauseNumber = clauseNumber;
    w->variableNumber = variableNumber;
    w->clauses = (clauseT *) malloc(clauseNumber * sizeof(clauseT));
    if(w->clauses == NULL){
        fprintf(stdout,"Allocation error!");
        exit(EXIT_FAILURE);
    }
    for(int i=0;i<clauseNumber;i++){
        w->clauses[i].result = 0;
        w->clauses[i].variables = (int *) calloc(variableNumber,sizeof(int));
        w->clauses[i].bits = (int *) calloc(variableNumber,sizeof(int));
        if(w->clauses[i].variables == NULL || w->clauses[i].bits == NULL){
            fprintf(stdout,"Allocation error!");
            exit(EXIT_FAILURE);
        }
    }
    return w;
}
void reset(wrapperT *w){
    for(int i=0;i<w->clauseNumber;i++){
        w->clauses[i].result = 0;
    }
}
int findSolutionWrapper(wrapperT *w,int *solution,int k){
    if(k == w->variableNumber){
        if(findSolution(w,solution) == 1){  //check if SAT condition hold
            printSolution(solution,w->variableNumber);
            return 1;
        }
        reset(w);   //reset results of all clauses to "0"
        return 0;
    }
    for(int i=0;i<=1;i++){
        solution[k] = i;
        if(findSolutionWrapper(w,solution,k+1) == 1)    //recur further into the recursion tree. If the path is correct, return 1 and avoid to continue visiting other paths
            return 1;
    }
    return 0;
}
int findSolution(wrapperT *w,int *solution){
    for(int i=0;i<w->clauseNumber;i++){
        for(int j=0;j<w->variableNumber;j++){
            w->clauses[i].bits[j] = solution[j];
        }
    }
    for(int i=0;i<w->clauseNumber;i++){
        for(int j=0;j<w->variableNumber;j++){
            if((w->clauses[i].variables[j] == 1 && w->clauses[i].bits[j] == 1) || (w->clauses[i].variables[j] == -1 && w->clauses[i].bits[j] == 0)){    //check if at least one (present) variable in the clause is a "1"
                w->clauses[i].result = 1;   //one "1" is enough to generate a "TRUE" result
                break;  //no need to go on with the current clause
            }
        }
    }
    for(int i=0;i<w->clauseNumber;i++){
        if(w->clauses[i].result == 0)   //check if at least one clause gives a result of "0"
            return 0;   //one "0" is enough to generate a "FALSE" result, this arrangement is not correct
    }
    return 1;   //this arrangement is correct
}
void printSolution(int *solution,int n){
    for(int i=0;i<n;i++)
        fprintf(stdout,"x%d: %d\n",i+1,solution[i]);
}
void freeAll(wrapperT *w){
    for(int i=0;i<w->clauseNumber;i++){
        free(w->clauses[i].variables);
        free(w->clauses[i].bits);
    }
    free(w->clauses);
}
